﻿using System;

namespace MasterActivator.enumerator
{
    public enum SpellType
    {
        SkillShotCircle = 0,
        SkillShotCone = 1,
        SkillShotLine = 2,
        TargetAll = 3,
        TargetEnemy = 4,
        TargetTeam = 5,
        Self = 6
    }
}
