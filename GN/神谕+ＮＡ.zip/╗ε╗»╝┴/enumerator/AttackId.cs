using System;

namespace MasterActivator.enumerator
{
    public enum AttackId
    {
        Unknown = -1,
        Q = 0,
        W = 1,
        E = 2,
        R = 3,
        King = 4,
        Basic = 5,
        Ignite = 6,
        Tower = 7,
        Spell = 8
    }
}
