using System;

namespace MasterActivator.enumerator
{
    public enum ItemTypeId
    {
        Offensive = 0,
        Purifier = 1,
        HPRegenerator = 2,
        ManaRegenerator = 3,
        Deffensive = 4,
        Buff = 5,
        DeffensiveSpell = 6,
        PurifierSpell = 7,
        ManaRegeneratorSpell = 8,
        OffensiveSpell = 9,
        Ability = 10,
        OffensiveAOE = 11,
        TeamAbility = 12,
        Ward = 13,
        VisionWard = 14,
        KSAbility = 15
    }
}
